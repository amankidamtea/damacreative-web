{{-- side bar --}}
<div class="d-block" style="background: #C8C8C8; height: 41px"></div>
<div class="container mt-5 mb-5">
    <div class="d-flex justify-content-around" id="sidebar">
        <div>
            <h4>Kategori</h4>
            <ul style="list-style: none;">
                <li><a href="" class="text-decoration-none text-dark">Desain Logo</a></li>
                <li><a href="" class="text-decoration-none text-dark">Desain Ilustrasi</a></li>
                <li><a href="" class="text-decoration-none text-dark">Desain Tamplate</a></li>
                <li><a href="" class="text-decoration-none text-dark">Desain Kemasan</a></li>
            </ul>
        </div>

        <div>
            <h4>Cara Penggunaan</h4>
            <ul style="list-style: none;">
                <li><a href="" class="text-decoration-none text-dark">Cara Mendaftar</a></li>
                <li><a href="" class="text-decoration-none text-dark">Cara Membeli Desain</a></li>
                <li><a href="" class="text-decoration-none text-dark">Cara Menjual Desain</a></li>
            </ul>
        </div>

        <div>
            <h4>Hubungi Kami</h4>
            <ul style="list-style: none;">
                <li><a href="" class="text-decoration-none text-dark">lorem@gamil.com</a></li>
                <li><a href="" class="text-decoration-none text-dark">+62 0000009</a></li>
            </ul>
        </div>
    </div>
</div>
{{-- end side bar --}}

<div class="d-block" style="background: #C8C8C8; height: 5px"></div>