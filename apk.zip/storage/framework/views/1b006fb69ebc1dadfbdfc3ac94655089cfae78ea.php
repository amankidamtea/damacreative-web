

<?php $__env->startSection('body'); ?>
    <main class="login mb-5">
        <div class="d-flex col-md-5 shadow-lg m-0 p-3 responsive bg-success rounded">
            <div class="col-md-6 p-3 border border-1 border-success rounded bg-white">
                <h2>Daftar</h2>
                <form action="">
                    <div class="input-group">
                        <label for="">Name</label>
                        <input type="text" value="" class="form-control">
                    </div>
                    <div class="input-group">
                        <label for="">Email</label>
                        <input type="text" value="" class="form-control">
                    </div>
                    <div class="input-group">
                        <label for="">Password</label>
                        <input type="password" value="" class="form-control" id="inputPassword">
                        <button type="button" class="toggle" onclick="passBtn()"><i id="eyeIcon" class="bi bi-eye"></i></button>
                    </div>
                    <div class="input-group">
                        <label for="">Confirm Password</label>
                        <input type="password" value="" class="form-control">
                    </div>
                    <button type="button" class="btn  btn-success mt-2 px-3  ">Daftar</button>
                </form>        
            </div>
            <div class="col-md-4 side-item">
                <h2 class="mt-3 text-white">Info</h2>
                <p align="justify" class="text-white">Silahkan daftar, jika sudah mempunyai akun silahkan masuk, klik <a href="" class="text-warning">disini</a> untuk masuk</p>
            </div>
        </div>
        
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\skripsi\skripsi apk\apk\resources\views/signin/signin.blade.php ENDPATH**/ ?>