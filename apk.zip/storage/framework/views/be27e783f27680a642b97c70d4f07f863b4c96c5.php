

<?php $__env->startSection('body'); ?>
    <main class="login">
        <div class="d-flex col-md-5 shadow-lg m-0 p-3 responsive bg-success rounded">
            <div class="col-md-6 p-3 border border-1 border-success rounded bg-white">
                <h2>Masuk</h2>
                <form action="">
                    <div class="input-group">
                        <label for="">Name</label>
                        <input type="text" value="" class="form-control">
                    </div>
                    <div class="input-group">
                        <label for="">Password</label>
                        <input type="password" value="" class="form-control" id="inputPassword">
                        <button type="button" class="toggle" id="btnToggle" onclick="passBtn()"><i id="eyeIcon" class="bi bi-eye"></i></button>
                    </div>
                    <a href="" class="nav-link m-0 p-0 forgot">lupa password</a>
                    <button type="button" class="btn btn-success mt-2">Masuk</button>
                </form>        
            </div>
            <div class="col-md-4 side-item">
                <h2 class="mt-3 text-white">Info</h2>
                <p align="justify" class="text-white">Silahkan masuk, jika tidak mempunyai akun silahkan daftar terlebih dahulu, klik <a href="" class="text-warning">disini</a> untuk melakukan pendaftaran</p>
            </div>
        </div>
        
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\skripsi apk\apk\resources\views/login/login.blade.php ENDPATH**/ ?>