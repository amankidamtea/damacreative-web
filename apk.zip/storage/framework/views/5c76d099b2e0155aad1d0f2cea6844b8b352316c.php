

<?php $__env->startSection('body'); ?>
    <div class="container">
        <div class="detail-box shadow">
            <div class="img">
                <img src="<?php echo e(asset('img/produk/1.avif')); ?>" alt="">
            </div>
            <div class="ket ms-5">
                <h1>Judul Desain</h1>
                <h3>Keterangan</h3>
                <p><i class="bi bi-check-circle"></i> Format Pdf</p>
                <p><i class="bi bi-check-circle"></i> Unlimited</p>
                <p><i class="bi bi-check-circle"></i> Exclusive</p>
                <h3 class="mt-2">Harga</h3>
                <p>Rp.200.000</p>
                <a href="" class="btn btn-primary">Download</a>
            </div>
        </div>

        <div class="mt-4 mb-4">
            <h2>Desain Lainnya</h2>
            <div class="produk">
                <div class="card-produk"><a href="/detail-produk"><img src="<?php echo e(asset('img/produk/11.avif')); ?>" alt=""></a></div>
                <div class="card-produk"><a href=""><img src="<?php echo e(asset('img/produk/12.avif')); ?>" alt=""></a></div>
                <div class="card-produk"><a href=""><img src="<?php echo e(asset('img/produk/13.avif')); ?>" alt=""></a></div>
                <div class="card-produk"><a href=""><img src="<?php echo e(asset('img/produk/14.avif')); ?>" alt=""></a></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\skripsi apk\apk\resources\views/detailProduk.blade.php ENDPATH**/ ?>