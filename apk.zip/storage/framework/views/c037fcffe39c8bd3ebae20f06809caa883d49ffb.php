


<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container p-2">
      <a class="brand" href="/"><img height="29" src="img/logo.svg" alt=""></a>
      <div class="menu">
        <input type="checkbox" id="checkbox">
        <span></span>
        <span></span>
        <span></span>
      </div>
      <div class="collapse navbar-collapse d-flex justify-content-between " id="navbar">
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Kategori
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li><a class="dropdown-item" href="#">Action</a></li>
                        <li><a class="dropdown-item" href="#">Another action</a></li>
                        <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link"  href="#">Cara Kerja</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/produk"">Semua Produk</a>
                </li>
                </ul>
            </ul>
            <ul class="navbar-nav float-end">
                <li class="nav-item">
                    <a class="nav-link" href="/login" >Masuk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/signin">Daftar</a>
                </li>
            </ul>
      </div>
    </div>
  </nav>
<?php /**PATH E:\laravel\skripsi apk\apk\resources\views/partial/navbar.blade.php ENDPATH**/ ?>