 
 <footer class="mt-4">
    <p class="text-center">Copyright&copy; 2023 by idham asegap</p>
</footer>
<?php /**PATH F:\skripsi\skripsi apk\apk\resources\views/partial/footer.blade.php ENDPATH**/ ?>